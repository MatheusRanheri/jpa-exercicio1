package br.org.fundatec.controller;

import br.org.fundatec.exception.AplicacaoException;
import br.org.fundatec.model.Aluno;
import br.org.fundatec.model.Materia;
import br.org.fundatec.model.MateriaTotalAlunos;
import br.org.fundatec.model.Nota;
import br.org.fundatec.repository.AlunoRepository;
import br.org.fundatec.repository.MateriaRepository;

import javax.persistence.PersistenceException;
import java.util.List;

public class EscolaController {

    private AlunoRepository alunoRepository;
    private MateriaRepository materiaRepository;


    public EscolaController() {
        this.alunoRepository = new AlunoRepository();
        this.materiaRepository = new MateriaRepository();
    }


    public void inserirAluno(String nome, String materiaNome, Integer nota) throws  AplicacaoException {
        Materia materia = materiaRepository.buscarPorNome(materiaNome);

        if(materia == null) {
            materia = new Materia(materiaNome);
        }

        Aluno aluno = new Aluno(nome);
        aluno.add(new Nota(nota, materia));

        try {
            alunoRepository.inserir(aluno);
        }catch (PersistenceException e) {
            throw new AplicacaoException("Falha ao inserir Aluno");
        }
    }

    public void inserirNota(Integer idAluno, String materiaNome, Integer nota) throws  AplicacaoException {
        Aluno aluno = alunoRepository.buscar(idAluno);

        if(aluno == null) {
            throw new AplicacaoException("Aluno nao encontrado");
        }

        Materia materia = materiaRepository.buscarPorNome(materiaNome);

        if(materia == null) {
            materia = new Materia(materiaNome);
        }

        aluno.add(new Nota(nota, materia));

        try {
            alunoRepository.atualizar(aluno);
        }catch (PersistenceException e) {
            throw new AplicacaoException("Falha ao inserir Nota");
        }
    }

    public List<Aluno> listarAlunos() {
        return alunoRepository.buscar();
    }

    public List<Materia> listarMaterias() {
        return materiaRepository.buscar();
    }

    public List<Nota> listarNotas(Integer idAluno) throws  AplicacaoException{
        Aluno aluno = alunoRepository.buscar(idAluno);

        if(aluno == null) {
            throw new AplicacaoException("Aluno nao encontrado");
        }

        return aluno.getNotas();
    }

    public List<MateriaTotalAlunos> getTotalAlunosPorMateria() throws  AplicacaoException{
        List<MateriaTotalAlunos> totais = materiaRepository.getTotalAlunosPorMateria();

        return totais;
    }
}
