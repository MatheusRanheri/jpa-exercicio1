package br.org.fundatec.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "NOTA")
public class Nota {

    @Id
    @GeneratedValue(strategy= GenerationType.TABLE , generator="nota_generator")
    @TableGenerator(name="nota_generator",
            table="chave",
            pkColumnName="id",
            valueColumnName="valor",
            allocationSize=100)
    @Column(name = "id")
    private Integer id;

    @Column(name = "nota")
    private Integer nota;

    @ManyToOne (fetch = FetchType.LAZY)
    @JoinColumn(name = "id_aluno", referencedColumnName = "id")
    private Aluno aluno;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_curso", referencedColumnName = "id")
    private Materia materia;

    public Nota() {
        super();
    }

    public Nota(Integer nota, Materia materia) {
        super();

        this.nota = nota;
        this.materia = materia;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNota() {
        return nota;
    }

    public void setNota(Integer nota) {
        this.nota = nota;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setMateria(Materia materia) {
        this.materia = materia;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Nota nota = (Nota) o;
        return id.equals(nota.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Nota{" +
                "nota=" + nota +
                ", materia=" + materia +
                '}';
    }
}
