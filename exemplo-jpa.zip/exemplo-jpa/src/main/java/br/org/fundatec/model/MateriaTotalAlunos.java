package br.org.fundatec.model;

public class MateriaTotalAlunos {

    private  String materia;
    private  long total;

    public MateriaTotalAlunos(String materia, long total) {
        this.materia = materia;
        this.total = total;
    }

    public String getMateria() {
        return materia;
    }

    public long getTotal() {
        return total;
    }

    @Override
    public String toString() {
        return "MateriaTotalAlunos{" +
                "materia='" + materia + '\'' +
                ", total=" + total +
                '}';
    }
}
