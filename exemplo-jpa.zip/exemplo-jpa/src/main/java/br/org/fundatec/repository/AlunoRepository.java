package br.org.fundatec.repository;

import br.org.fundatec.model.Aluno;

import javax.persistence.*;
import java.util.List;

public class AlunoRepository {

    private EntityManager em;

    public AlunoRepository() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("EscolaDB");
        em = factory.createEntityManager();
    }

    public void inserir(Aluno aluno) {
        this.em.getTransaction().begin();
        this.em.merge(aluno);
        this.em.getTransaction().commit();
    }

    public List<Aluno> buscar() {
        TypedQuery<Aluno> buscarTodosQuery = this.em.createQuery("select e from Aluno e", Aluno.class);
        return buscarTodosQuery.getResultList();
    }

    public Aluno buscar(Integer id) {
        return  this.em.find(Aluno.class, id);
    }

    public void atualizar(Aluno aluno) {
        this.em.merge(aluno);
    }

    public void remove(Aluno aluno) {
        this.em.remove(aluno);
    }
}
