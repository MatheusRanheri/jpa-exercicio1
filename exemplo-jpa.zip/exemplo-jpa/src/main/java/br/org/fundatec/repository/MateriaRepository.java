package br.org.fundatec.repository;

import br.org.fundatec.model.Materia;
import br.org.fundatec.model.MateriaTotalAlunos;

import javax.persistence.*;
import java.util.List;

public class MateriaRepository {

    private EntityManager em;

    public MateriaRepository() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("EscolaDB");
        em = factory.createEntityManager();
    }

    public void inserir(Materia materia) {
        this.em.getTransaction().begin();
        this.em.persist(materia);
        this.em.getTransaction().commit();
    }

    public List<Materia> buscar() {
        TypedQuery<Materia> buscarTodosQuery = this.em.createQuery("select e from Materia e", Materia.class);
        return buscarTodosQuery.getResultList();
    }

    public Materia buscarPorNome(String nome) {
        TypedQuery<Materia> query = this.em.createQuery("select e from Materia e where e.nome like :nome", Materia.class);
        query.setParameter("nome", nome);

        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }

    }

    /*
      SELECT  MT.NOME, COUNT(AL.ID) AS TOTAL
        FROM NOTA AS NT
            INNER JOIN ALUNO AS AL ON NT.ID_ALUNO = AL.ID
            INNER JOIN MATERIA AS MT ON NT.ID_CURSO = MT.ID
      GROUP BY MT.NOME
     */
    public List<MateriaTotalAlunos> getTotalAlunosPorMateria() {
        StringBuffer sb = new StringBuffer(50);
        sb.append("select new br.org.fundatec.model.MateriaTotalAlunos(m.nome, COUNT(a.id)) ");
        sb.append("   from Nota e ");
        sb.append(" inner join e.aluno a ");
        sb.append(" inner join e.materia m ");
        sb.append("  group by m.nome");

        Query query = this.em.createQuery(sb.toString(), MateriaTotalAlunos.class);

        try {
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }
}
