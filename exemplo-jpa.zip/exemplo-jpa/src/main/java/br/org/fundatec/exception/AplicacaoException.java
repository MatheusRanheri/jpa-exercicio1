package br.org.fundatec.exception;

public class AplicacaoException  extends Exception {

    public  AplicacaoException(String mensagem) {
        super(mensagem);
    }

}
